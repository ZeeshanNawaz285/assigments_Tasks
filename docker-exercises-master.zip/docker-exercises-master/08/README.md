# Description
in the docker-compose file add a delay before a service starts

## Run instructions

