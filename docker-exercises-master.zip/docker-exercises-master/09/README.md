# Description
Run a Fluent container and then run various other containers sending their log output to the Fluent container.


## Run instructions


