# Description
How can you tell whether or not the ubuntu:16.4 image is signed for content trust?

#Answer


