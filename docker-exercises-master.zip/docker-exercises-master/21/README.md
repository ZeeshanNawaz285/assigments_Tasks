# Description

Can you create an image using only the scratch base image?

## Run instructions

Create a Dockerfile containing only the following (or some variation) and try to build it:

    FROM scratch



