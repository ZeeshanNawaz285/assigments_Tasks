# Description

Can a local docker-composer service container connect to a container running in another cluster?

## Run instructions



