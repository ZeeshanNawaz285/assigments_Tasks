# Description
What is the smallest data only container you can make?


## Run instructions

