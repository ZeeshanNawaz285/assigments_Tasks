# Description
What command will most quickly tell you what is contained in an Alpine Linux /etc/hosts file?

## Run instructions

