# Description
AWS ECR is an image registry service that is integrated with the AWS ECS service.

