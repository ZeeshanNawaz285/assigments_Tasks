# Description
Docker images can be interesting to look around in.
You can save images to a tar archive and then extract the layers and metadata files from them.

tar commands look like the following:

    list tar archive contents - tar tvf archive
    extract tar archive contents - tar xvf archive

## Run instructions

Extract each of the layers in an alpine image.




