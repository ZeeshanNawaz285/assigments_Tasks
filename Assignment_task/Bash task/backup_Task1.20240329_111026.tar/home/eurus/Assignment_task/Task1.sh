#!/bin/bash



while read  line; do
    echo "$line"    
    echo            
done < T1_file.txt

