#!/bin/bash

#constant variable 
readonly college="gordon clg"

echo "my clg name is  $college"

college="test"

echo "new clg name is $college"
