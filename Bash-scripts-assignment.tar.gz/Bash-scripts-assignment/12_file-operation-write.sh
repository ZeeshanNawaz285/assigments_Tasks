#!/bin/bash 


#You can write data to a file using redirection or echo...... means to over write data   

#echo "why you are Deleted previous data" > "testfile.txt"


#To append data to a file without overwriting existing content, use double redirection:

echo "welcome to office" >> "testfile.txt"


