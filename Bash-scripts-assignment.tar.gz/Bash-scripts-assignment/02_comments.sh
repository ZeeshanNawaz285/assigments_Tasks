#!/bin/bash

echo "checking comments"

#this is a single line comment 


<<comment 
this 
is 
multi
line comments 
comment

