#!/bin/bash 

#create a function

function wel() {
echo ".................."
echo "welcome $1"
echo "age is $2"
echo ".................."
}

#to call a function 

wel zeeshan 20
wel nawaz 10
