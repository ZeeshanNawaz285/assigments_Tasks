#!/bin/bash


echo "this is a pen" >> "output.txt"


cat > "testfile.txt"
This is line 1
This is line 2
^D

