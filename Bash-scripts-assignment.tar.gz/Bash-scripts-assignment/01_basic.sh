#!/bin/bash

echo "salam"
