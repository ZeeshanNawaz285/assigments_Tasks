#!/bin/bash 

#create a function

function wel() {
echo ".................."
echo "welcome"
echo ".................."
}

#to call a function 

wel 
wel
wel

